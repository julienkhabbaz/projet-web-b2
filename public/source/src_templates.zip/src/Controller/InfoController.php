<?php

namespace App\Controller;


use Symfony\Bundle\FrameworkBundle\Controller\AbstractController;
use Symfony\Component\Routing\Annotation\Route;

class InfoController extends AbstractController
{
    /**
     * @Route("/", name="homepage")
     */
    public function index()
    {
        return $this->render('info/index.html.twig');
    }
    /**
     * @Route("/form", name="forms")
     */
    public function form()
    {
        return $this->render('info/form.html.twig');
    }
    /**
     * @Route("/table", name="table")
     */
    public function table()
    {
        return $this->render('info/table.html.twig');
    }



}
